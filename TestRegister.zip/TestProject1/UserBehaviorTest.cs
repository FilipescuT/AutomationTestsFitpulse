﻿using AutomationWorkshop.Pages;
using AutomationWorkshop.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace AutomationWorkshop
{
    [TestClass]
    public class UserBehaviorTest
    {
        private IWebDriver driver;
        [TestInitialize]
        public void SetupTest()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://localhost:4200/Register");
        }
        [TestCleanup]
        public void CleanupTest()
        {
            driver.Quit();
        }
        [TestMethod]
        public void Should_CreateUserAccount_When_RegisterFormContainsValidData()
        {
           
            var registerPage = new RegisterPage(driver);
            var expectedTitle = "Register";
            var actualTitle = registerPage.GetPageTitle();
            Assert.AreEqual(expectedTitle, actualTitle);

            
            User user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Age = "34",
                Weight = "70",
                Height = "180",
                Gender = "male",
                Email = "john.doe@gmail.com",
                Username = "johndoe",
                Password = "password",
                ConfirmPassword = "password"
            };

            var accountPage = registerPage.FillInRegisterForm(user);

           
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(driver => driver.Url.Contains("/Login"));

            Assert.IsTrue(accountPage.IsLoginPageUrl(), "The URL does not contain /Login after registration.");
        }


    }
}