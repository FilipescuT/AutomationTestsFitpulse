﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationWorkshop.Pages
{
    internal class LandingPage
    {
        private IWebDriver browser;
        public LandingPage(IWebDriver driver)
        {
           browser = driver;
        }
        //locators 
        private IWebElement RegisterLink => browser.FindElement(By.LinkText("Register"));

        //methods

        public RegisterPage GoToRegisterPage()
        {
            return new RegisterPage(browser);
        }

    }
}
