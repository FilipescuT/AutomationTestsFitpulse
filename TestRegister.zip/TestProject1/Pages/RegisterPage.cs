﻿using AutomationWorkshop.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AutomationWorkshop.Pages
{
    public class RegisterPage
    {
        private IWebDriver browser;
        public RegisterPage(IWebDriver driver)
        {
            browser = driver;
        }
        //locators

        private IWebElement RegisterPageTitle => browser.FindElement(By.TagName("h1"));   

        private IWebElement FirstName=> browser.FindElement(By.Id("firstNameId"));
        private IWebElement LastName => browser.FindElement(By.Id("lastNameId"));

        private IWebElement Age => browser.FindElement(By.Id("ageId"));
        private IWebElement Weight => browser.FindElement(By.Id("weightId"));
        private IWebElement Height => browser.FindElement(By.Id("heightId"));
        private IWebElement Gender => browser.FindElement(By.Id("genderId"));
        private IWebElement Email => browser.FindElement(By.Id("emailId"));
        
        private IWebElement Username => browser.FindElement(By.Id("usernameId"));
        private IWebElement Password => browser.FindElement(By.Id("passwordId"));
        private IWebElement ConfirmPassword => browser.FindElement(By.Id("confirmPasswordId"));
        private IWebElement RegisterButton => browser.FindElement(By.Id("registerId"));
        private IWebElement NextButton => browser.FindElement(By.Id("nextId"));
       


        //methods
        public string GetPageTitle()
        {
            return RegisterPageTitle.Text;
        }
       
        public AccountPage FillInRegisterForm(User user)
        {
            WebDriverWait wait = new WebDriverWait(browser, TimeSpan.FromSeconds(20));

            FirstName.SendKeys(user.FirstName);
            LastName.SendKeys(user.LastName);
            Age.SendKeys(user.Age);
            Weight.SendKeys(user.Weight);
            Height.SendKeys(user.Height);

            
            Gender.Click(); 
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath($"//mat-option[@value='{user.Gender}']")));
            browser.FindElement(By.XPath($"//mat-option[@value='{user.Gender}']")).Click();

            NextButton.Click();

            
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("emailId")));

            Email.SendKeys(user.Email);
            Username.SendKeys(user.Username);
            Password.SendKeys(user.Password);
            ConfirmPassword.SendKeys(user.ConfirmPassword);
            RegisterButton.Click();

           
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.UrlContains("Login"));

            return new AccountPage(browser);
        }



    }
}
