﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationWorkshop.Pages
{
    public class AccountPage
    {
        private IWebDriver browser;
        public AccountPage(IWebDriver driver)
        {
            browser = driver;
        }
        // locator pentru un element specific paginii de login
    //    private IWebElement LoginButton => browser.FindElement(By.Id("loginId"));

   
        public bool IsLoginPageUrl()
        {
            return browser.Url.Contains("http://localhost:4200/Login");
        }

    }

}
